var checkboxSelection = function (params) {
  // we put checkbox on the name if we are not doing grouping
  return params.columnApi.getRowGroupColumns().length === 0;
};
var headerCheckboxSelection = function (params) {
  // we put checkbox on the name if we are not doing grouping
  return params.columnApi.getRowGroupColumns().length === 0;
};

var dateFilterParams = {
  comparator: (filterLocalDateAtMidnight, cellValue) => {
    var dateAsString = cellValue;
    if (dateAsString == null) return -1;
    var dateParts = dateAsString.split('/');
    var cellDate = new Date(
      Number(dateParts[2]),
      Number(dateParts[1]) - 1,
      Number(dateParts[0])
    );

    if (filterLocalDateAtMidnight.getTime() === cellDate.getTime()) {
      return 0;
    }

    if (cellDate < filterLocalDateAtMidnight) {
      return -1;
    }

    if (cellDate > filterLocalDateAtMidnight) {
      return 1;
    }
  },
  browserDatePicker: true,
};
function after2010() {
  var dateFilterComponent = gridOptions.api.getFilterInstance('date');
  dateFilterComponent.setModel({
    type: 'greaterThan',
    dateFrom: '01-01-2010',
    dateTo: null,
  });

  gridOptions.api.onFilterChanged();
}

function before2012() {
  var dateFilterComponent = gridOptions.api.getFilterInstance('date');
  dateFilterComponent.setModel({
    type: 'lessThan',
    dateFrom: '01-01-2012',
    dateTo: null,
  });

  gridOptions.api.onFilterChanged();
}

function dateCombined() {
  var dateFilterComponent = gridOptions.api.getFilterInstance('date');
  dateFilterComponent.setModel({
    condition1: {
      type: 'lessThan',
      dateFrom: '01-01-2012',
      dateTo: null,
    },
    operator: 'OR',
    condition2: {
      type: 'greaterThan',
      dateFrom: '01-01-2012',
      dateTo: null,
    },
  });

  gridOptions.api.onFilterChanged();
}

function clearDateFilter() {
  var dateFilterComponent = gridOptions.api.getFilterInstance('date');
  dateFilterComponent.setModel(null);
  gridOptions.api.onFilterChanged();
}
function onBtExport() {
  gridOptions.api.exportDataAsExcel();
}
var autoGroupColumnDef = {
  headerName: 'Group',
  minWidth: 170,
  field: 'athlete',
  valueGetter: (params) => {
    if (params.node.group) {
      return params.node.key;
    } else {
      return params.data[params.colDef.field];
    }
  },
  headerCheckboxSelection: true,
  cellRenderer: 'agGroupCellRenderer',
  cellRendererParams: {
    checkbox: true,
  },
};
const columnDefs = [
    {
    headerName: 'Athlete',
    children: [
    { field: 'athlete',rowDrag: true ,  minWidth: 200,checkboxSelection: checkboxSelection,
    headerCheckboxSelection: headerCheckboxSelection,  filter: 'agTextColumnFilter'  },
    { field: 'age',hide:true,suppressMenu: false,minWidth: 150, filter: 'agTextColumnFilter'  },
      { field: 'country',hide:true, suppressMenu: false,minWidth: 200, filter: 'agTextColumnFilter' },
   ],},
   {
    headerName: 'Competition',
    children: [{ field: 'year',suppressMenu: false,minWidth: 200, filter: 'agNumberColumnFilter', }, 
    { field: 'date', hide:true,
    filter: 'agDateColumnFilter',minWidth: 200, dateFormat: 'd/m/Y',
    filterParams: dateFilterParams,
    suppressMenu: false,

     
      menuTabs: ['filterMenuTab', 'generalMenuTab', 'columnsMenuTab'], }],
  },
  { field: 'sport', minWidth: 150,
     
       },
  {
    headerName: 'Medals',
    children: [
      { field: 'gold',hide:true,enableRowGroup: false,suppressMenu: false, minWidth: 150,filter: 'agTextColumnFilter',
      menuTabs: ['generalMenuTab', 'gibberishMenuTab'], },
      { field: 'silver',hide:true,enableRowGroup: false,suppressMenu: false,minWidth: 150, filter: 'agTextColumnFilter',
      menuTabs: ['generalMenuTab', 'gibberishMenuTab'], },
      { field: 'bronze',hide:true,enableRowGroup: false,suppressMenu: false, minWidth: 150,filter: 'agTextColumnFilter',
      menuTabs: ['generalMenuTab', 'gibberishMenuTab'], },
      { field: 'total',minWidth: 150,enableRowGroup: false,filter: 'agNumberColumnFilter', },
    ],
  },
    
   
  ];
  var tooltipRenderer = function(params)
{
    return '<span title="' + params.value + '">'+params.value+'</span>';
};
  const gridOptions = {
      
    columnDefs: columnDefs,
    
     
  columnDefs: columnDefs,
  animateRows: true,
    defaultColDef: {
    flex: 1,
   
    enableRowGroup: true,
    enablePivot: true,
    enableValue: true,
    // minWidth: 50,
    floatingFilter: true,
    suppressColumnsToolPanel:false,
    filter: true,
    resizable: true,
    sortable: true,
    showToolPanel:false,
    cellRenderer: tooltipRenderer,
    
    }, 
    animateRows: true,
    rowDragManaged: false,
  suppressMoveWhenRowDragging: true,
  
    sideBar: {
        toolPanels: [
            {
                id: 'columns',
                labelDefault: 'Columns',
                labelKey: 'columns',
                iconKey: 'columns',
                toolPanel: 'agColumnsToolPanel',
                minWidth: 225,
                maxWidth: 225,
                width: 225
            },
            {
                id: 'filters',
                labelDefault: 'Filters',
                labelKey: 'filters',
                iconKey: 'filter',
                toolPanel: 'agFiltersToolPanel',
                minWidth: 180,
                maxWidth: 400,
                width: 250
            },
            
        ],
        position: 'right',
        defaultToolPanel: ''
    },
    autoGroupColumnDef: {
    minWidth: 200,
  },
  suppressExcelExport: true,
  popupParent: document.body,
 
  rowSelection: 'multiple',
//   animateRows: true,
    hiddenByDefault:true,
      defaultToolPanel:false,
     pivotPanelShow: 'always',
    tooltipShowDelay: 1000,
  tooltipMouseTrack: true,
  suppressRowClickSelection: true,
  groupSelectsChildren: true,
  debug: true,
  cacheQuickFilter: true,
  
  ensureDomOrder: true,
  suppressColumnVirtualisation: true,
  suppressRowVirtualisation: true,
  enableRangeSelection: true,

  pagination: true,
  paginationPageSize: 100,
  autoGroupColumnDef: autoGroupColumnDef,

  onFirstDataRendered: onFirstDataRendered,
paginationNumberFormatter: (params) => {
    return '[' + params.value.toLocaleString() + ']';
  },
  // set rowData to null or undefined to show loading panel by default
  rowData: null,
  columnDefs: columnDefs,
    getMainMenuItems: getMainMenuItems,
    // postProcessPopup: (params) => {
    //   // check callback is for menu
    //   if (params.type !== 'columnMenu') {
    //     return;
    //   }
    //   const columnId = params.column ? params.column.getId() : undefined;
    //   if (columnId === 'gold') {
    //     const ePopup = params.ePopup;
  
    //     let oldTopStr = ePopup.style.top;
    //     // remove 'px' from the string (AG Grid uses px positioning)
    //     oldTopStr = oldTopStr.substring(0, oldTopStr.indexOf('px'));
    //     const oldTop = parseInt(oldTopStr);
    //     const newTop = oldTop + 25;
  
    //     ePopup.style.top = newTop + 'px';
    //   }
    // }
    
  };
  function onFirstDataRendered(params) {
  params.api.paginationGoToPage(0);
}
function onBtSuppressRowDrag() {
  gridOptions.api.setSuppressRowDrag(true);
}

function onBtShowRowDrag() {
  gridOptions.api.setSuppressRowDrag(false);
}
function setText(selector, text) {
  document.querySelector(selector).innerHTML = text;
};
function onFilterTextBoxChanged() {
  gridOptions.api.setQuickFilter(
    document.getElementById('filter-text-box').value
  );
}


 function onRowCount() {
  var value = document.getElementById('row-count').value;
  gridOptions.api.paginationGetRowCount(Number(value));
}

function onPageSizeChanged() {
  var value = document.getElementById('page-size').value;
  gridOptions.api.paginationSetPageSize(Number(value));
}

  function getMainMenuItems(params) {
    // you don't need to switch, we switch below to just demonstrate some different options
    // you have on how to build up the menu to return
    switch (params.column.getId()) {
      // return the defaults, put add some extra items at the end
      case 'athlete':
        const athleteMenuItems = params.defaultItems.slice(0);
        // athleteMenuItems.push({
        //   name: 'AG Grid Is Great',
        //   action: () => {
        //     console.log('AG Grid is great was selected');
        //   },
        // });
        // athleteMenuItems.push({
        //   name: 'Casio Watch',
        //   action: () => {
        //     console.log('People who wear casio watches are cool');
        //   },
        // });
        // athleteMenuItems.push({
        //   name: 'Custom Sub Menu',
        //   subMenu: [
        //     {
        //       name: 'Black',
        //       action: () => {
        //         console.log('Black was pressed');
        //       },
        //     },
        //     {
        //       name: 'White',
        //       action: () => {
        //         console.log('White was pressed');
        //       },
        //     },
        //     {
        //       name: 'Grey',
        //       action: () => {
        //         console.log('Grey was pressed');
        //       },
        //     },
        //   ],
        // });
        return athleteMenuItems;
  
      // return some dummy items
      case 'age':
        return [
          {
            // our own item with an icon
            name: 'Joe Abercrombie',
            action: () => {
              console.log('He wrote a book');
            },
            icon:
              '<img src="https://www.ag-grid.com/example-assets/lab.png" style="width: 14px;" />',
          },
          {
            // our own icon with a check box
            name: 'Larsson',
            action: () => {
              console.log('He also wrote a book');
            },
            checked: true,
          },
          'resetColumns', // a built in item
        ];
  
      // return all the default items, but remove app separators and the two sub menus
      case 'country':
        const countryMenuItems = [];
        const itemsToExclude = ['separator', 'pinSubMenu', 'valueAggSubMenu'];
        params.defaultItems.forEach((item) => {
          if (itemsToExclude.indexOf(item) < 0) {
            countryMenuItems.push(item);
          }
        });
        return countryMenuItems;
  
      default:
        // make no changes, just accept the defaults
        return params.defaultItems;
    }
  }
  
  // setup the grid after the page has finished loading
  document.addEventListener('DOMContentLoaded', () => {
    const gridDiv = document.querySelector('#myGrid');
    new agGrid.Grid(gridDiv, gridOptions);
  
    fetch('https://www.ag-grid.com/example-assets/olympic-winners.json')
      .then((response) => response.json())
      .then((data) => {
        gridOptions.api.setRowData(data);
      });
  });