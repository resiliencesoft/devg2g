<?php
$con = mysqli_connect("Localhost","unisim_user","7xo0wrvk*6SP","unisim_db") or die("database connection error");
?>