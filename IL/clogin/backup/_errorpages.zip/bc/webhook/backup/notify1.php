<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/PHPMailer/src/Exception.php';
require 'PHPMailer/PHPMailer/src/PHPMailer.php';
require 'PHPMailer/PHPMailer/src/SMTP.php';
include("config.php");

// $result = json_decode(file_get_contents('php://input'), true);

$orderid          = '10973';
$newstatusid      = '11';

if(!empty($orderid))
{
    if($newstatusid=='11')
    {
        $headers = array(
            'X-Auth-Token: lvznqmz5lad75u9m76lqaoebbouwe80',
            'Content-Type: application/json',
            'Accept: application/json'
        );
        $curl = curl_init();
        $url = 'https://api.bigcommerce.com/stores/7cb2a64bch/v2/orders/'.$orderid.'/products';
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        $state_result = curl_exec($curl);
        $presult = json_decode($state_result,true); 
        
        $total_item = count($presult);
        $i = 0;
        foreach($presult AS $presults)
        {
            $item_no = ++$i;
            $pro_name = $presults['sku'];
            $sku_array = explode("_",$presults['sku']);
            $sku = $sku_array[0].'_'.$sku_array[1];
            $logourl = "https://alerts.unisimcard.biz/bc/webhook/logo.png";
            
            if($sku=='SKU_AC')
            {
                $add_products = mysqli_query($con, "insert into product_details (info_id,order_id,variant_id,name_customer,sku,type,quantity,activation_date) values ('".$presults['id']."','".$presults['order_id']."','".$presults['variant_id']."','".$presults['name_customer']."','".$presults['sku']."','".$presults['type']."','".$presults['quantity']."','$activate')");
                $insert_id = mysqli_insert_id($con);
                $activate_date = $presults['product_options'][1]['display_value'];
                $activate_array = explode(" ",$presults['product_options'][1]['display_value']);
                $activate = date("Y-m-d", strtotime($activate_array['2'].'-'.$activate_array['1'].'-'.sprintf("%02d",substr_replace($activate_array[0] ,"", -2))));
                $start_date = $activate.' 00:00:00';
                $end_date   = date('Y-m-d', strtotime("+29 day")).' 00:00:00';
                $check_orderid = mysqli_query($con, "select * from iccid where Order_ID='$orderid'");
                if(mysqli_num_rows($check_orderid)==0)
                {
                    $select_iccid = mysqli_query($con, "select * from iccid where Status='' LIMIT 1");
                    if(mysqli_num_rows($select_iccid)==1)
                    {   
                        $iccidrow = mysqli_fetch_assoc($select_iccid);
                        $data = $iccidrow['LPA_Value'];
                        $filename = time().'.png';
                        $savePath = "qr/".$filename;
                        $sizeValue = 400;
                        $size = '400x400';
                        $logo = "https://alerts.unisimcard.biz/bc/webhook/logo.jpeg";
                        header('Content-type: image/png');
                        $QR = imagecreatefrompng('https://chart.googleapis.com/chart?cht=qr&chld=H|1&chs='.$size.'&chl='.urlencode($data));
                        if($logo !== FALSE){
                            $logo = imagecreatefromstring(file_get_contents($logo));
                            $QR_width = imagesx($QR);
                            $QR_height = imagesy($QR);
                            $logo_width = imagesx($logo);
                            $logo_height = imagesy($logo);
                            // Scale logo to fit in the QR Code
                            $logo_qr_width = $QR_width/3;
                            $scale = $logo_width/$logo_qr_width;
                            $logo_qr_height = $logo_height/$scale;
                            
                            imagecopyresampled($QR, $logo, $QR_width/3, $QR_height/2.5, 0, 0, $logo_qr_width, $logo_qr_height, $logo_width, $logo_height);
                        }
                        $iccidd  = "ICCID: ".$iccidrow['ICCID'];
                        $number  = "Number: ".$iccidrow['Number'];
                        $plan    = "IMSI: ".$iccidrow['IMSI'];
                        //$email  = "Order Id: 10512";
                        
                        $finalImg = imagecreatetruecolor($sizeValue, $sizeValue+100);
                        $white = imageColorAllocate($finalImg, 255, 255, 255);
                        $black = imageColorAllocate($finalImg, 0, 0, 0);
                        $font = 'arial.ttf';
                        imagefill($finalImg, 0, 0, $white);
                        imagecopymerge($finalImg,$QR,0,8,0,0,$sizeValue,$sizeValue, 100);
                        if($sizeValue < 250) {
                            imagettftext($finalImg, 14, 0, 10, $sizeValue+25, $black, $font, $iccidd);
                            imagettftext($finalImg, 14, 0, 10, $sizeValue+50, $black, $font, $uk);
                            imagettftext($finalImg, 14, 0, 10, $sizeValue+75, $black, $font, $plan);
                            //imagettftext($finalImg, 14, 0, 10, $sizeValue+100, $black, $font, $email);
                        } else {
                            imagettftext($finalImg, 14, 0, 20, $sizeValue+25, $black, $font, $iccidd);
                            imagettftext($finalImg, 14, 0, 20, $sizeValue+50, $black, $font, $uk);
                            imagettftext($finalImg, 14, 0, 20, $sizeValue+75, $black, $font, $plan);
                            //imagettftext($finalImg, 14, 0, 20, $sizeValue+100, $black, $font, $email);
                        }
                        if(imagepng($finalImg, $savePath))
                        {
                            $update = mysqli_query($con, "update iccid set Status='Pending', Order_ID='$orderid' where id='".$iccidrow['id']."'");
                            if($update)
                            {
                                $curl = curl_init();
                                $url = 'https://api.bigcommerce.com/stores/7cb2a64bch/v2/orders/'.$orderid;
                                curl_setopt($curl, CURLOPT_URL, $url);
                                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
                                curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
                                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                                curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
                                $state_result = curl_exec($curl);
                                $orderresult = json_decode($state_result,true); 
                                $modified = explode(" ",$orderresult['date_modified']);
                                $modified_date = date("Y-m-d h:i:s", strtotime($modified[3].'-'.$modified[2].'-'.$modified[1].' '.$modified[4]));
                                $created = explode(" ",$orderresult['date_created']);
                                $created_date = date("Y-m-d h:i:s", strtotime($created[3].'-'.$created[2].'-'.$created[1].' '.$created[4]));
                                
                                $add_orders = mysqli_query($con, "insert into orders (order_id,status_id,status,items_total,payment_status,refunded_amount,ip_address,geoip_country,currency_code,customer_message,first_name,last_name,company,street_1,street_2,city,state,zip,country,country_iso2,phone,email,order_source,modified_date,created_at) values ('".$orderresult['id']."','".$orderresult['status_id']."','".$orderresult['status']."','".$orderresult['items_total']."','".$orderresult['payment_status']."','".$orderresult['refunded_amount']."','".$orderresult['ip_address']."','".$orderresult['geoip_country']."','".$orderresult['currency_code']."','".$orderresult['customer_message']."','".$orderresult['billing_address']['first_name']."','".$orderresult['billing_address']['last_name']."','".$orderresult['billing_address']['company']."','".$orderresult['billing_address']['street_1']."','".$orderresult['billing_address']['street_2']."','".$orderresult['billing_address']['city']."','".$orderresult['billing_address']['state']."','".$orderresult['billing_address']['zip']."','".$orderresult['billing_address']['country']."','".$orderresult['billing_address']['country_iso2']."','".$orderresult['billing_address']['phone']."','".$orderresult['billing_address']['email']."','".$orderresult['order_source']."','$modified_date','$created_date')");    
                                if($add_orders)
                                {
                                    $headers = array(
                                        'X-Auth-Token: lvznqmz5lad75u9m76lqaoebbouwe80',
                                        'Content-Type: application/json',
                                        'Accept: application/json'
                                    );
                        
                                    $post_body = array();
                                    $post_body['auth_info'] = json_encode(array('login' => 'esimAPI', 'password' => '$0%6YrU$jJRh'));
                                    $params = array('id' => $iccidrow['ICCID']);
                                    $post_body['params'] = json_encode($params);
                                    $URL = "https://mybilling.globalvoiceconnect.com:443/rest/Account/get_account_info";
                                    $response = sendCurlPost($URL, $post_body);
                                    http_response_code($response['info']['http_code']);
                                    $iccidresult = json_decode($response['data'],true); 
                                    $iaccount    = $iccidresult['account_info']['i_account'];
                                    if(isset($iaccount))
                                    {
                                        $fname = $orderresult['billing_address']['first_name'];
                                        $lname = $orderresult['billing_address']['last_name'];
                                        $email = $orderresult['billing_address']['email'];
                                        mysqli_query($con, "update iccid set i_account='$iaccount' where id='".$iccidrow['id']."'");
                                        $post_body = array();
                                        $post_body['auth_info'] = json_encode(array('login' => 'esimAPI', 'password' => '$0%6YrU$jJRh'));
                                        $params = array('account_info' => array("i_account" => $iaccount, "firstname" => $fname, "lastname" => $lname, "subscriber_email" => $email, "email" => $email));
                                        $post_body['params'] = json_encode($params);
                                        $URL = "https://mybilling.globalvoiceconnect.com:443/rest/Account/update_account";
                                        $response = sendCurlPost($URL, $post_body);
                                        http_response_code($response['info']['http_code']);
                                        $updateuser = json_decode($response['data'],true); 
                                        if(isset($updateuser['i_account']))
                                        {
                                            $post_body = array();
                                            $post_body['auth_info'] = json_encode(array('login' => 'esimAPI', 'password' => '$0%6YrU$jJRh'));
                                            $params = array('offset'=>0, 'name'=> $pro_name);
                                            $post_body['params'] = json_encode($params);
                                            $URL = "https://mybilling.telinta.com:443/rest/Product/get_product_list";
                                            $response = sendCurlPost($URL, $post_body);
                                            http_response_code($response['info']['http_code']);
                                            $uresult = json_decode($response['data'],true); 
                                            $iproduct = $uresult['product_list'][0]['i_product'];
                                            $update_simno = mysqli_query($con, "update product_details set i_account='$iaccount', product_id='$iproduct' where id='$insert_id'");
                                            if(isset($iproduct))
                                            {
                                                mysqli_query($con, "update iccid set product_id='$iproduct' where id='".$iccidrow['id']."'");
                                                $post_body = array();
                                                $post_body['auth_info'] = json_encode(array('login' => 'esimAPI', 'password' => '$0%6YrU$jJRh'));
                                                $params = array(
                                                    'account_info' => array("i_account" => $iaccount,
                                                        "assigned_addons" => [
                                                            array("i_product"=>$iproduct, "addon_effective_from"=>$start_date, "addon_effective_to"=>$end_date)
                                                        ]));
                                                $post_body['params'] = json_encode($params);
                                                $URL = "https://mybilling.telinta.com:443/rest/Account/update_account";
                                                $response = sendCurlPost($URL, $post_body);
                                                http_response_code($response['info']['http_code']);
                                                $result = json_decode($response['data'],true); 
                                                if(isset($result['i_account']))
                                                {
                                                    $data = array('status_id'=>'10');
                                                    $headers = array(
                                                        'X-Auth-Token: lvznqmz5lad75u9m76lqaoebbouwe80',
                                                        'Content-Type: application/json',
                                                        'Accept: application/json'
                                                    );
                                                    $curl = curl_init();
                                                    $url = 'https://api.bigcommerce.com/stores/7cb2a64bch/v2/orders/'.$orderid;
                                                    curl_setopt($curl, CURLOPT_URL, $url);
                                                    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
                                                    curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
                                                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                                                    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
                                                    $state_result = curl_exec($curl);
                                                    $result1 = json_decode($state_result,true); 
                                                    if(!empty($result1['id']) && $result1['id']==$orderid)
                                                    {
                                                        mysqli_query($con, "update iccid set Status='Success' where id='".$iccidrow['id']."'");
                                                        $sku_val = "SKU_AC";
                                                        $status = "Success";
                                                        $val = "Success";
                                                    }
                                                }
                                                else
                                                {
                                                    $sku_val = "SKU_AC";
                                                    $status = "Pending";
                                                    $val = "Status Change API Failed";
                                                }
                                            }
                                            else
                                            {
                                                $sku_val = "SKU_AC";
                                                $status = "Pending";
                                                $val = "Get Product List API Not Run";
                                            }
                                        }
                                        else{
                                            $sku_val = "SKU_AC";
                                            $status = "Pending";
                                            $val = "Account Information Update API Not Run";
                                        }
                                    }
                                    else
                                    {
                                        $sku_val = "SKU_AC";
                                        $status = "Pending";
                                        $val = "Get Account INFO API Not Run";
                                    }
                                }
                                else
                                {
                                    $sku_val = "SKU_AC";
                                    $status = "Pending";
                                    $val = "Order API Not Run";
                                }
                            }
                            else
                            {
                                $sku_val = "SKU_AC";
                                $status = "Pending";
                                $val = "SKU is Not Equal SKU_AC";
                            }
                        }
                    }
                    else
                    {
                        $sku_val = "SKU_AC";
                        $status = "Pending";
                        $val = "ICCID NOT FOUND";
                    }
                }
            }

            if($sku=='SKU_RE')
            {
                $add_products = mysqli_query($con, "insert into product_details (info_id,order_id,variant_id,name_customer,sku,type,quantity,activation_date) values ('".$presults['id']."','".$presults['order_id']."','".$presults['variant_id']."','".$presults['name_customer']."','".$presults['sku']."','".$presults['type']."','".$presults['quantity']."','$activate')");
                $insert_id = mysqli_insert_id($con);
                $iccid = $presults['product_options'][2]['display_value'];
                
                $activate_date = $presults['product_options'][3]['display_value'];
                $activate_array = explode(" ",$presults['product_options'][3]['display_value']);
                $activate = date("Y-m-d", strtotime($activate_array['2'].'-'.$activate_array['1'].'-'.sprintf("%02d",substr_replace($activate_array[0] ,"", -2))));
                $start_date = $activate.' 00:00:00';
                $end_date   = date('Y-m-d', strtotime("+29 day")).' 00:00:00';
                $headers = array(
                    'X-Auth-Token: lvznqmz5lad75u9m76lqaoebbouwe80',
                    'Content-Type: application/json',
                    'Accept: application/json'
                );
                $curl = curl_init();
                $url = 'https://api.bigcommerce.com/stores/7cb2a64bch/v2/orders/'.$orderid;
                curl_setopt($curl, CURLOPT_URL, $url);
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
                curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
                $state_result = curl_exec($curl);
                $orderresult = json_decode($state_result,true); 
                
                $modified = explode(" ",$orderresult['date_modified']);
                $modified_date = date("Y-m-d h:i:s", strtotime($modified[3].'-'.$modified[2].'-'.$modified[1].' '.$modified[4]));
                $created = explode(" ",$orderresult['date_created']);
                $created_date = date("Y-m-d h:i:s", strtotime($created[3].'-'.$created[2].'-'.$created[1].' '.$created[4]));
                
                $fname = $orderresult['billing_address']['first_name'];
                $lname = $orderresult['billing_address']['last_name'];
                $email = $orderresult['billing_address']['email'];
                $add_orders = mysqli_query($con, "insert into orders (order_id,status_id,status,items_total,payment_status,refunded_amount,ip_address,geoip_country,currency_code,customer_message,first_name,last_name,company,street_1,street_2,city,state,zip,country,country_iso2,phone,email,order_source,modified_date,created_at) values ('".$orderresult['id']."','".$orderresult['status_id']."','".$orderresult['status']."','".$orderresult['items_total']."','".$orderresult['payment_status']."','".$orderresult['refunded_amount']."','".$orderresult['ip_address']."','".$orderresult['geoip_country']."','".$orderresult['currency_code']."','".$orderresult['customer_message']."','".$orderresult['billing_address']['first_name']."','".$orderresult['billing_address']['last_name']."','".$orderresult['billing_address']['company']."','".$orderresult['billing_address']['street_1']."','".$orderresult['billing_address']['street_2']."','".$orderresult['billing_address']['city']."','".$orderresult['billing_address']['state']."','".$orderresult['billing_address']['zip']."','".$orderresult['billing_address']['country']."','".$orderresult['billing_address']['country_iso2']."','".$orderresult['billing_address']['phone']."','".$orderresult['billing_address']['email']."','".$orderresult['order_source']."','$modified_date','$created_date')");    
                if($add_orders)
                {
                    $headers = array(
                        'X-Auth-Token: lvznqmz5lad75u9m76lqaoebbouwe80',
                        'Content-Type: application/json',
                        'Accept: application/json'
                    );
    
                    $post_body = array();
                    $post_body['auth_info'] = json_encode(array('login' => 'esimAPI', 'password' => '$0%6YrU$jJRh'));
                    $params = array('id' => $iccid);
                    $post_body['params'] = json_encode($params);
                    $URL = "https://mybilling.globalvoiceconnect.com:443/rest/Account/get_account_info";
                    $response = sendCurlPost($URL, $post_body);
                    http_response_code($response['info']['http_code']);
                    $iccidresult = json_decode($response['data'],true); 
                    //$iaccount    = $iccidresult['account_info']['i_account'];
                    
                    if(isset($iccidresult['account_info']['i_master_account']))
                    {
                        $iaccount    = $iccidresult['account_info']['i_master_account'];
                    } else{
                        $iaccount    = $iccidresult['account_info']['i_account'];
                    }
                
                    if(isset($iaccount))
                    {
                        $post_body = array();
                        $post_body['auth_info'] = json_encode(array('login' => 'esimAPI', 'password' => '$0%6YrU$jJRh'));
                        $params = array('offset'=>0, 'name'=> $pro_name);
                        $post_body['params'] = json_encode($params);
                        $URL = "https://mybilling.telinta.com:443/rest/Product/get_product_list";
                        $response = sendCurlPost($URL, $post_body);
                        http_response_code($response['info']['http_code']);
                        $uresult = json_decode($response['data'],true); 
                        $iproduct = $uresult['product_list'][0]['i_product'];
                        $update_simno = mysqli_query($con, "update product_details set i_account='$iaccount', product_id='$iproduct', simNo='$iccid' where id='$insert_id'");
                        if(isset($iproduct))
                        {
                            $post_body = array();
                            $post_body['auth_info'] = json_encode(array('login' => 'esimAPI', 'password' => '$0%6YrU$jJRh'));
                            $params = array(
                                'account_info' => array("i_account" => $iaccount,
                                    "assigned_addons" => [
                                        array("i_product"=>$iproduct, "addon_effective_from"=> $start_date, "addon_effective_to"=> $end_date)
                                    ]));
                            $post_body['params'] = json_encode($params);
                            $URL = "https://mybilling.telinta.com:443/rest/Account/update_account";
                            $response = sendCurlPost($URL, $post_body);
                            http_response_code($response['info']['http_code']);
                            $result = json_decode($response['data'],true); 
                            if(isset($result['i_account']))
                            {
                                $data = array('status_id'=>'10');
                                $headers = array(
                                    'X-Auth-Token: lvznqmz5lad75u9m76lqaoebbouwe80',
                                    'Content-Type: application/json',
                                    'Accept: application/json'
                                );
                                $curl = curl_init();
                                $url = 'https://api.bigcommerce.com/stores/7cb2a64bch/v2/orders/'.$orderid;
                                curl_setopt($curl, CURLOPT_URL, $url);
                                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
                                curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
                                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                                curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
                                $state_result = curl_exec($curl);
                                $result1 = json_decode($state_result,true); 
                                if(!empty($result1['id']) && $result1['id']==$orderid)
                                {
                                    $sku_val = "SKU_RE";
                                    $status = "Success";
                                    $val = "Success";
                                }
                                else
                                {
                                    $sku_val = "SKU_RE";
                                    $status = "Pending";
                                    $val = "Status Update API Failed";
                                }
                            }
                            else
                            {
                                $sku_val = "SKU_RE";
                                $status = "Pending";
                                $val = "Update Account API Failed";
                            }
                        }
                        else
                        {
                            $sku_val = "SKU_RE";
                            $status = "Pending";
                            $val = "Get Product List API Failed";
                        }
                    }
                    else
                    {
                        $sku_val = "SKU_RE";
                        $status = "Invalid Number";
                        $val = "Invalid Number";
                    }
                }
                else
                {
                    $sku_val = "SKU_RE";
                    $status = "Pending";
                    $val = "Order API Failed";
                }
            }
            
            
            // SKU_AC Mail for Customer
            if(isset($status,$sku_val) && $status!="" && $sku_val=="SKU_AC")
            {
                $message = '<table align="center" cellspacing="0" cellpadding="0" style="width: 540px; margin: 0px auto; font-family: Helvetica; letter-spacing: normal; text-indent: 0px; text-transform: none; word-spacing: 0px; text-decoration: none;">
                        <tbody>
                            <tr>
                                <td>
                                    <table cellspacing="0" cellpadding="0" style="width: 500px; margin: 0px 20px;">
                                        <tbody>
                                            <tr>
                                                <td style="border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(234, 234, 234); padding: 10px 0px 0px 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td width="250">
                                                                    <img src="'.$logourl.'"
                                                                        style="border: 0px; margin: 0px; height: 50px;" /><br>
                                                                </td>
                                                                <td width="250" valign="top" align="right"><div style="margin: 0px; font-size: 18px; font-family: arial, sans-serif;"></div></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding-left: 0px; padding-top: 9px; padding-bottom: 9px;">
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif;">Dear '.$fname.' '.$lname.', </div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">Welcome to UniSimCard Global eSIM </div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">Please find below some important information regarding your eSIM:</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">ICCID: '.$iccidrow['ICCID'].'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Account_ID: '.$iaccount.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Phone: '.$iccidrow['Number'].'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Plan: <span style="font-weight:bold">'.$pro_name.'</span></div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Activation Date: '.$activate_date.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Order_ID: '.$orderid.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Item No : '.$item_no.'/'.$total_item.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Status: '.$status.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">Scan the QR code to install eSIM</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">
                                                        <img src="https://alerts.unisimcard.biz/bc/webhook/'.$savePath.'" style="border: 0px; margin: 0px; height: 400px;" />
                                                    </div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">
            		                                UniSimCard<br>
                                                     T: + 972.3.720.8144<br> 
                                                     T: +1.754.229.4002<br>
                                                    Whatsapp: ‪+972 55‑966‑158<br>8‬
                                                     e: info@unisimcard.biz<br>
                                                     w: www.unisimcard.biz
            		                                </div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">****************************</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">How to set up your UniSimCard eSIM attached:</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">* Important notice: once the eSIM is installed on your phone you can’t delete it or reinstall it, in the case that you do, you will need to purchase a new eSIM, your balance or remaining plan will be transferred to the new eSIM</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">
                                                        Quick Dial Numbers<br>
                                                        141 - Check balance (only for pay as you go option)<br>
                                                        142 - "Get my numbers"<br>
                                                        143 - set caller-ID for outgoing calls. Should be dialed as 143. DID must be one of the DID aliases that belong to the SIM subscriber<br>
                                                        144 - top-up account balance with a voucher. Should be dialed as 144 <br>
                                                        152 - enable VM<br>
                                                        153 - disable VM<br>
                                                        156 - enable call forwarding. Should be dialed as 156<br>
                                                        157 - disable call forwarding<br>
                                                        190 - get backoffice password<br>
                                                        *145*8888*10 send top up via CC (credit card most be on file, only for pay as you go option)
                                                    </div>
                                                    <div style="margin: 0px; font-size: 12px; font-family: arial, sans-serif; padding-top: 15px;">
                                                    If you would like to use our voice app to make and receive calls during or after your trip on your UniSimCard number <br>
                                                    Please read more https://www.unisimcard.biz/calling-plans-long-distance/</div>
                                                    <div style="margin: 0px; font-size: 12px; font-family: arial, sans-serif; padding-top: 15px;">
                                                    For more information and FAQ please visit our main website<br>
                                                    https://www.unisimcard.biz/faq.html</div>
                                                    <div style="margin: 0px; font-size: 12px; font-family: arial, sans-serif; padding-top: 15px;">
                                                    To recharge your plan or to buy a new plan you can go to <br>
                                                    https://www.unisimcard.biz/topup/</div>
                                                    <div style="margin: 0px; font-size: 12px; font-family: arial, sans-serif; padding-top: 15px;">* Important notice: once the eSIM is installed on your phone you can’t delete it or reinstall it, in the case that you do, you will need to purchase a new eSIM, your balance or remaining plan will be transferred to the new eSIM</div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>';
                    
                $fromEmail = "unisimcard@globalvoiceconnect.com";
                $sub = "UniSImCard eSIM: ".$pro_name." [Order_ID: ".$orderid."]";
                $mail = new PHPMailer(true);
                $mail->isSMTP(); 
                $mail->Host = 'smtp.gmail.com'; 
                $mail->SMTPAuth = true;  
                $mail->Username = 'unisimcard@globalvoiceconnect.com'; 
                $mail->Password = 'UniSimcard2022@';
                $mail->SMTPSecure = 'TLS'; 
                $mail->Port = 587;
                $mail->setFrom("unisimcard@globalvoiceconnect.com", "Unisimcard");
                $mail->addReplyTo("unisimcard@globalvoiceconnect.com","Unisimcard");
                $mail->addAddress($email);
                $mail->addBCC("sunil@roam1.com");
                $mail->addBCC("samin@roam1.com");
                $mail->addBCC("ivan@globalvoiceconnect.com");
                $mail->addAttachment('esim_guide.pdf');
                $mail->isHTML(true);
                $mail->Subject = $sub;
                $mail->Body    = $message;
                $mail->send();
            }
            
            // SKU_AC Mail for Support
            if(isset($val,$sku_val) && $val!="" && $sku_val=="SKU_AC")
            {
                $message = '<table align="center" cellspacing="0" cellpadding="0" style="width: 540px; margin: 0px auto; font-family: Helvetica; letter-spacing: normal; text-indent: 0px; text-transform: none; word-spacing: 0px; text-decoration: none;">
                        <tbody>
                            <tr>
                                <td>
                                    <table cellspacing="0" cellpadding="0" style="width: 500px; margin: 0px 20px;">
                                        <tbody>
                                            <tr>
                                                <td style="border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(234, 234, 234); padding: 10px 0px 0px 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td width="250">
                                                                    <img src="'.$logourl.'"
                                                                        style="border: 0px; margin: 0px; height: 50px;" /><br>
                                                                </td>
                                                                <td width="250" valign="top" align="right"><div style="margin: 0px; font-size: 18px; font-family: arial, sans-serif;"></div></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding-left: 0px; padding-top: 9px; padding-bottom: 9px;">
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif;">Dear '.$fname.' '.$lname.', </div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">Welcome to UniSimCard Global eSIM </div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">Please find below some important information regarding your eSIM:</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">ICCID: '.$iccidrow['ICCID'].'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Account_ID: '.$iaccount.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Phone: '.$iccidrow['Number'].'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Plan: <span style="font-weight:bold">'.$pro_name.'</span></div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Activation Date: '.$activate_date.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Order_ID: '.$orderid.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Status: '.$status.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Item No : '.$item_no.'/'.$total_item.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Error: '.$val.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">Scan the QR code to install eSIM</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">
                                                        <img src="https://alerts.unisimcard.biz/bc/webhook/'.$savePath.'" style="border: 0px; margin: 0px; height: 400px;" />
                                                    </div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">
            		                                UniSimCard<br>
                                                     T: + 972.3.720.8144<br> 
                                                     T: +1.754.229.4002<br>
                                                    Whatsapp: ‪+972 55‑966‑158<br>8‬
                                                     e: info@unisimcard.biz<br>
                                                     w: www.unisimcard.biz
            		                                </div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">****************************</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">How to set up your UniSimCard eSIM attached:</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">* Important notice: once the eSIM is installed on your phone you can’t delete it or reinstall it, in the case that you do, you will need to purchase a new eSIM, your balance or remaining plan will be transferred to the new eSIM</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">
                                                        Quick Dial Numbers<br>
                                                        141 - Check balance (only for pay as you go option)<br>
                                                        142 - "Get my numbers"<br>
                                                        143 - set caller-ID for outgoing calls. Should be dialed as 143. DID must be one of the DID aliases that belong to the SIM subscriber<br>
                                                        144 - top-up account balance with a voucher. Should be dialed as 144 <br>
                                                        152 - enable VM<br>
                                                        153 - disable VM<br>
                                                        156 - enable call forwarding. Should be dialed as 156<br>
                                                        157 - disable call forwarding<br>
                                                        190 - get backoffice password<br>
                                                        *145*8888*10 send top up via CC (credit card most be on file, only for pay as you go option)
                                                    </div>
                                                    <div style="margin: 0px; font-size: 12px; font-family: arial, sans-serif; padding-top: 15px;">
                                                    If you would like to use our voice app to make and receive calls during or after your trip on your UniSimCard number <br>
                                                    Please read more https://www.unisimcard.biz/calling-plans-long-distance/</div>
                                                    <div style="margin: 0px; font-size: 12px; font-family: arial, sans-serif; padding-top: 15px;">
                                                    For more information and FAQ please visit our main website<br>
                                                    https://www.unisimcard.biz/faq.html</div>
                                                    <div style="margin: 0px; font-size: 12px; font-family: arial, sans-serif; padding-top: 15px;">
                                                    To recharge your plan or to buy a new plan you can go to <br>
                                                    https://www.unisimcard.biz/topup/</div>
                                                    <div style="margin: 0px; font-size: 12px; font-family: arial, sans-serif; padding-top: 15px;">* Important notice: once the eSIM is installed on your phone you can’t delete it or reinstall it, in the case that you do, you will need to purchase a new eSIM, your balance or remaining plan will be transferred to the new eSIM</div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>';
                    
                $fromEmail = "unisimcard@globalvoiceconnect.com";
                $sub = "UniSImCard eSIM: ".$pro_name." [Order_ID: ".$orderid."]";
                $mail = new PHPMailer(true);
                $mail->isSMTP(); 
                $mail->Host = 'smtp.gmail.com'; 
                $mail->SMTPAuth = true;  
                $mail->Username = 'unisimcard@globalvoiceconnect.com'; 
                $mail->Password = 'UniSimcard2022@';
                $mail->SMTPSecure = 'TLS'; 
                $mail->Port = 587;
                $mail->setFrom("unisimcard@globalvoiceconnect.com", "Unisimcard");
                $mail->addReplyTo("unisimcard@globalvoiceconnect.com","Unisimcard");
                //$mail->addAddress("sunil@roam1.com");
                //$mail->addAddress("samin@roam1.com");
                $mail->addAddress("ivan@globalvoiceconnect.com");
                $mail->addBCC("sunil@roam1.com");
                $mail->addBCC("samin@roam1.com");
                $mail->addAttachment('esim_guide.pdf');
                $mail->isHTML(true);
                $mail->Subject = $sub;
                $mail->Body    = $message;
                $mail->send();
            }
            
            // SKU_RE Mail for Customer
            if(isset($status,$sku_val) && $status!="" && $sku_val=="SKU_RE")
            {
                $message = '<table align="center" cellspacing="0" cellpadding="0" style="width: 540px; margin: 0px auto; font-family: Helvetica; letter-spacing: normal; text-indent: 0px; text-transform: none; word-spacing: 0px; text-decoration: none;">
                        <tbody>
                            <tr>
                                <td>
                                    <table cellspacing="0" cellpadding="0" style="width: 500px; margin: 0px 20px;">
                                        <tbody>
                                            <tr>
                                                <td style="border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(234, 234, 234); padding: 10px 0px 0px 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td width="250">
                                                                    <img src="'.$logourl.'"
                                                                        style="border: 0px; margin: 0px; height: 50px;" /><br>
                                                                </td>
                                                                <td width="250" valign="top" align="right"><div style="margin: 0px; font-size: 18px; font-family: arial, sans-serif;"></div></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding-left: 0px; padding-top: 9px; padding-bottom: 9px;">
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif;">Dear '.$fname.' '.$lname.', </div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">Your eSIM has been recharged: </div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">SIM Number: '.$iccid.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">Recharge Plan: <span style="font-weight:bold">'.$pro_name.'</span></div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Activation Date: '.$activate_date.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Order_ID: '.$orderid.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Account_ID: '.$iaccount.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Item No : '.$item_no.'/'.$total_item.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Status: '.$status.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">
            		                                UniSimCard<br>
                                                     T: + 972.3.720.8144<br> 
                                                     T: +1.754.229.4002<br>
                                                    Whatsapp: ‪+972 55‑966‑158<br>8‬
                                                     e: info@unisimcard.biz<br>
                                                     w: www.unisimcard.biz
            		                                </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>';
                    
                $fromEmail = "unisimcard@globalvoiceconnect.com";
                $sub = "UniSImCard eSIM: ".$pro_name." [Order_ID: ".$orderid."]";
                $mail = new PHPMailer(true);
                $mail->isSMTP(); 
                $mail->Host = 'smtp.gmail.com'; 
                $mail->SMTPAuth = true;  
                $mail->Username = 'unisimcard@globalvoiceconnect.com'; 
                $mail->Password = 'UniSimcard2022@';
                $mail->SMTPSecure = 'TLS'; 
                $mail->Port = 587;
                $mail->setFrom("unisimcard@globalvoiceconnect.com", "Unisimcard");
                $mail->addReplyTo("unisimcard@globalvoiceconnect.com","Unisimcard");
                $mail->addAddress($email);
                $mail->addBCC("sunil@roam1.com");
                $mail->addBCC("samin@roam1.com");
                $mail->addBCC("ivan@globalvoiceconnect.com");
                $mail->isHTML(true);
                $mail->Subject = $sub;
                $mail->Body    = $message;
                $mail->send();
            }
            
            // SKU_RE Mail for Support
            if(isset($val,$sku_val) && $val!="" && $sku_val=="SKU_RE")
            {
                $message = '<table align="center" cellspacing="0" cellpadding="0" style="width: 540px; margin: 0px auto; font-family: Helvetica; letter-spacing: normal; text-indent: 0px; text-transform: none; word-spacing: 0px; text-decoration: none;">
                        <tbody>
                            <tr>
                                <td>
                                    <table cellspacing="0" cellpadding="0" style="width: 500px; margin: 0px 20px;">
                                        <tbody>
                                            <tr>
                                                <td style="border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(234, 234, 234); padding: 10px 0px 0px 0px;">
                                                    <table cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td width="250">
                                                                    <img src="'.$logourl.'"
                                                                        style="border: 0px; margin: 0px; height: 50px;" /><br>
                                                                </td>
                                                                <td width="250" valign="top" align="right"><div style="margin: 0px; font-size: 18px; font-family: arial, sans-serif;"></div></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding-left: 0px; padding-top: 9px; padding-bottom: 9px;">
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif;">Dear '.$fname.' '.$lname.', </div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">Your eSIM has been recharged: </div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">SIM Number: '.$iccid.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">Recharge Plan: <span style="font-weight:bold">'.$pro_name.'</span></div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Activation Date: '.$activate_date.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Order_ID: '.$orderid.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Account_ID: '.$iaccount.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Item No : '.$item_no.'/'.$total_item.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Status: '.$status.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Error: '.$val.'</div>
                                                    <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">
            		                                UniSimCard<br>
                                                     T: + 972.3.720.8144<br> 
                                                     T: +1.754.229.4002<br>
                                                    Whatsapp: ‪+972 55‑966‑158<br>8‬
                                                     e: info@unisimcard.biz<br>
                                                     w: www.unisimcard.biz
            		                                </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>';
                    
                $fromEmail = "unisimcard@globalvoiceconnect.com";
                $sub = "UniSImCard eSIM: ".$pro_name." [Order_ID: ".$orderid."]";
                $mail = new PHPMailer(true);
                $mail->isSMTP(); 
                $mail->Host = 'smtp.gmail.com'; 
                $mail->SMTPAuth = true;  
                $mail->Username = 'unisimcard@globalvoiceconnect.com'; 
                $mail->Password = 'UniSimcard2022@';
                $mail->SMTPSecure = 'TLS'; 
                $mail->Port = 587;
                $mail->setFrom("unisimcard@globalvoiceconnect.com", "Unisimcard");
                $mail->addReplyTo("unisimcard@globalvoiceconnect.com","Unisimcard");
                //$mail->addAddress("sunil@roam1.com");
                //$mail->addAddress("samin@roam1.com");
                $mail->addAddress("ivan@globalvoiceconnect.com");
                $mail->addBCC("sunil@roam1.com");
                $mail->addBCC("samin@roam1.com");
                $mail->isHTML(true);
                $mail->Subject = $sub;
                $mail->Body    = $message;
                $mail->send();
            }
            
        }
    }
}

function sendCurlPost($url, $post_body)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_body);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    $res = curl_exec($ch);
    $info = curl_getinfo($ch);
    return array('data'=>$res, 'info'=>$info);
}
?>