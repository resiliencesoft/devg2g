<?php
$data = array('status_id'=>'11');
$headers = array(
    'X-Auth-Token: lvznqmz5lad75u9m76lqaoebbouwe80',
    'Content-Type: application/json',
    'Accept: application/json'
);

$curl = curl_init();
$url = 'https://api.bigcommerce.com/stores/7cb2a64bch/v2/orders/10512';
curl_setopt($curl, CURLOPT_URL, $url);
// curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
// curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
$state_result = curl_exec($curl);
$result = json_decode($state_result,true); 
  
echo "<pre>";
print_r($result);  
?>