<?php
$headers = array(
    'X-Auth-Token: lvznqmz5lad75u9m76lqaoebbouwe80',
    'Content-Type: application/json',
    'Accept: application/json'
);
$curl = curl_init();
$url = 'https://api.bigcommerce.com/stores/7cb2a64bch/v2/orders/10943/products';
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
$state_result = curl_exec($curl);
$result = json_decode($state_result,true); 
echo "<pre>";
print_r($result);

echo $total_item = count($result);
$i = 0;
foreach($result AS $presults)
{
    echo $item_no = ++$i;
    // $sku_array = explode("_",$result[0]['sku']);
    // $sku = $sku_array[0].'_'.$sku_array[1];
    // $activate = $result[0]['product_options'][1]['display_value'];
    
    $pro_name = $presults['sku'];
    $sku_array = explode("_",$presults['sku']);
    $sku = $sku_array[0].'_'.$sku_array[1];
    $activate_date = $presults['product_options'][3]['display_value'];
    $activate_array = explode(" ",$presults['product_options'][3]['display_value']);
    $activate = date("Y-m-d", strtotime($activate_array['2'].'-'.$activate_array['1'].'-'.sprintf("%02d",substr_replace($activate_array[0] ,"", -2))));
    $start_date = $activate.' 00:00:00';
    $end_date   = date('Y-m-d', strtotime("+29 day")).' 00:00:00';
    $logourl = "https://alerts.unisimcard.biz/bc/webhook/logo.png";
}



function sendCurlPost($url, $post_body)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_body);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    $res = curl_exec($ch);
    $info = curl_getinfo($ch);
    return array('data'=>$res, 'info'=>$info);
}
?>