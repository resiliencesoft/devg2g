<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/PHPMailer/src/Exception.php';
require 'PHPMailer/PHPMailer/src/PHPMailer.php';
require 'PHPMailer/PHPMailer/src/SMTP.php';




// Mail for Support

$message = '<h1>hello</h1>';
    
$fromEmail = "info@unisimcard.biz";
$sub = "UniSImCard eSIM: SKU_AC_EUROPE 500MB [Order_ID: 10512]";
$mail = new PHPMailer(true);
$mail->isSMTP(); 
$mail->Host = 'smtp.office365.com'; 
$mail->SMTPAuth = true;  
$mail->Username = 'info@unisimcard.biz'; 
$mail->Password = 'UniSimcard2022@';
$mail->SMTPSecure = 'tls'; 
$mail->Port = 587;  
$mail->setFrom("info@unisimcard.biz", "Unisimcard");
$mail->addReplyTo("info@unisimcard.biz","Unisimcard");
$mail->addAddress("sunilgpatel007@gmail.com");
//$mail->addAddress("samin@roam1.com");
$mail->isHTML(true);
$mail->Subject = $sub;
$mail->Body    = $message;
$mail->send();
