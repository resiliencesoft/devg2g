<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/PHPMailer/src/Exception.php';
require 'PHPMailer/PHPMailer/src/PHPMailer.php';
require 'PHPMailer/PHPMailer/src/SMTP.php';

// Mail for Support
$message = '<h1>hello 66</h1>';
    
$fromEmail = "unisimcard@globalvoiceconnect.com";
$sub = "25 UniSImCard eSIM: SKU_AC_EUROPE 500MB [Order_ID: 10512]";
$mail = new PHPMailer(true);
$mail->isSMTP(); 
$mail->Host = 'smtp.gmail.com'; 
$mail->SMTPAuth = true;  
$mail->Username = 'unisimcard@globalvoiceconnect.com'; 
$mail->Password = 'UniSimcard2022@';
$mail->SMTPSecure = 'TLS'; 
$mail->Port = 587;  
$mail->setFrom("unisimcard@globalvoiceconnect.com", "Unisimcard");
$mail->addReplyTo("unisimcard@globalvoiceconnect.com","UniSimcard");
$mail->addAddress("meetsamin@icloud.com");
$mail->addAddress("sunil@roam1.com");
$mail->addAddress("ivan@globalvoiceconnect.com");
//$mail->addAddress("samin@roam1.com");
$mail->isHTML(true);
$mail->Subject = $sub;
$mail->Body    = $message;
$mail->send();
