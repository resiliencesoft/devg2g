<?php
// use PHPMailer\PHPMailer\PHPMailer;
// use PHPMailer\PHPMailer\Exception;
// require 'PHPMailer/PHPMailer/src/Exception.php';
// require 'PHPMailer/PHPMailer/src/PHPMailer.php';
// require 'PHPMailer/PHPMailer/src/SMTP.php';

$logourl = "https://alerts.unisimcard.biz/bc/webhook/logo.png";
$message = '<table align="center" cellspacing="0" cellpadding="0" style="width: 540px; margin: 0px auto; font-family: Helvetica; letter-spacing: normal; text-indent: 0px; text-transform: none; word-spacing: 0px; text-decoration: none;">
			    <tbody>
			        <tr>
			            <td>
			                <table cellspacing="0" cellpadding="0" style="width: 500px; margin: 0px 20px;">
			                    <tbody>
			                        <tr>
			                            <td style="border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(234, 234, 234); padding: 10px 0px 0px 0px;">
			                                <table cellspacing="0" cellpadding="0">
			                                    <tbody>
			                                        <tr>
			                                            <td width="250">
			                                                <img src="'.$logourl.'"
			                                                    style="border: 0px; margin: 0px; height: 40px;" /><br>
			                                            </td>
			                                            <td width="250" valign="top" align="right"><div style="margin: 0px; font-size: 18px; font-family: arial, sans-serif;"></div></td>
			                                        </tr>
			                                    </tbody>
			                                </table>
			                            </td>
			                        </tr>
			                        <tr>
			                            <td style="padding-left: 0px; padding-top: 9px; padding-bottom: 9px;">
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif;">Dear Customer name, </div>
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">Welcome to UniSimCard Global eSIM </div>
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">Please find below some important information regarding your eSIM:</div>
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">eSIM # xxxxx</div>
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Phone:  xxxx</div>
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Plan: <span style="font-weight:bold">eSIM Europe</span> [name_customer] </div>
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Activation Date:</div>
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 5px;">Order_ID: </div>
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">QR_Code image here</div>
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">Scan the QR code to install eSIM</div>
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">
			                                UniSimCard<br>
                                             T: + 972.3.720.8144<br> 
                                             T: +1.754.229.4002<br>
                                            Whatsapp: ‪+972 55‑966‑158<br>8‬
                                             e: info@unisimcard.biz<br>
                                             w: www.unisimcard.biz
			                                </div>
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">****************************</div>
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">How to set up your UniSimCard eSIM attached:</div>
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">* Important notice: once the eSIM is installed on your phone you can’t delete it or reinstall it, in the case that you do, you will need to purchase a new eSIM, your balance or remaining plan will be transferred to the new eSIM</div>
			                                <div style="margin: 0px; font-size: 11px; font-family: arial, sans-serif; padding-top: 15px;">
    			                                Quick Dial Numbers<br>
                                                141 - Check balance (only for pay as you go option)<br>
                                                142 - "Get my numbers"<br>
                                                143 - set caller-ID for outgoing calls. Should be dialed as 143. DID must be one of the DID aliases that belong to the SIM subscriber<br>
                                                144 - top-up account balance with a voucher. Should be dialed as 144 <br>
                                                152 - enable VM<br>
                                                153 - disable VM<br>
                                                156 - enable call forwarding. Should be dialed as 156<br>
                                                157 - disable call forwarding<br>
                                                190 - get backoffice password<br>
                                                *145*8888*10 send top up via CC (credit card most be on file, only for pay as you go option)
			                                </div>
			                                <div style="margin: 0px; font-size: 12px; font-family: arial, sans-serif; padding-top: 15px;">
			                                If you would like to use our voice app to make and receive calls during or after your trip on your UniSimCard number <br>
                                            Please read more https://www.unisimcard.biz/calling-plans-long-distance/</div>
                                            <div style="margin: 0px; font-size: 12px; font-family: arial, sans-serif; padding-top: 15px;">
                                            For more information and FAQ please visit our main website<br>
                                            https://www.unisimcard.biz/faq.html</div>
                                            <div style="margin: 0px; font-size: 12px; font-family: arial, sans-serif; padding-top: 15px;">
                                            To recharge your plan or to buy a new plan you can go to <br>
                                            https://www.unisimcard.biz/topup/</div>
                                            <div style="margin: 0px; font-size: 12px; font-family: arial, sans-serif; padding-top: 15px;">* Important notice: once the eSIM is installed on your phone you can’t delete it or reinstall it, in the case that you do, you will need to purchase a new eSIM, your balance or remaining plan will be transferred to the new eSIM</div>
			                            </td>
			                        </tr>
			                    </tbody>
			                </table>
			            </td>
			        </tr>
			    </tbody>
			</table>';


echo $message;

// $fromEmail = "support@weconference.in";
// $emails = array("samin@roam1.com","sunil@roam1.com");
// $sub = "Test Subject";

// $mail = new PHPMailer(true);
// $mail->isSMTP(); 
// $mail->Host = 'smtp.mail.us-west-2.awsapps.com'; 
// $mail->SMTPAuth = true;  
// $mail->Username = 'support@weconference.in'; 
// $mail->Password = 'CCIcci1!';
// $mail->SMTPSecure = 'ssl'; 
// $mail->Port = 465;  
// $mail->setFrom("support@weconference.in", "CCPL TT Dashboard");
// $mail->addReplyTo("support@weconference.in","CCPL TT Dashboard");

// foreach($emails as $email) {
//     $mail->addAddress($email);
// }
//$mail->addAddress($gmail, $name);  
//$mail->addAddress('sunil@roam1.com');
// $mail->addAddress('samin@roam1.com');

// if($cc != '') {
//     $ccArray = explode(",", $cc);
//     foreach($ccArray as $ccValue) {
//         $mail->AddCC($ccValue);
//     }
// }

// if($bcc != '') {
//     $bccArray = explode(",", $bcc);
//     foreach($bccArray as $bccValue) {
//         $mail->addBCC($bccValue);
//     }
// }

// $mail->isHTML(true);
// $mail->Subject = $sub;
// $mail->Body    = $message;
// $mail->send();
?>