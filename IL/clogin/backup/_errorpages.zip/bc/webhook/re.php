<?php
include("config.php");

$orderid          = '10907';
$newstatusid      = '11';

$data = "ewds";
$headers = array(
    'X-Auth-Token: lvznqmz5lad75u9m76lqaoebbouwe80',
    'Content-Type: application/json',
    'Accept: application/json'
);
$curl = curl_init();
$url = 'https://api.bigcommerce.com/stores/7cb2a64bch/v2/orders/'.$orderid.'/products';
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
$state_result = curl_exec($curl);
$presult = json_decode($state_result,true); 
echo "<pre>";
print_r($presult);
$pro_name = $presult[0]['sku'];
$sku_array = explode("_",$presult[0]['sku']);
$sku = $sku_array[0].'_'.$sku_array[1];
$imsi = $presult[0]['product_options'][2]['display_value'];
$activate_array = explode(" ",$presult[0]['product_options'][3]['display_value']);
$activate = date("Y-m-d", strtotime($activate_array['2'].'-'.$activate_array['1'].'-'.sprintf("%02d",substr_replace($activate_array[0] ,"", -2))));

// if($sku=='SKU_RE')
// {
//     $imsi = $presult[0]['product_options'][2]['display_value'];
//     $headers = array(
//         'X-Auth-Token: lvznqmz5lad75u9m76lqaoebbouwe80',
//         'Content-Type: application/json',
//         'Accept: application/json'
//     );
//     $curl = curl_init();
//     $url = 'https://api.bigcommerce.com/stores/7cb2a64bch/v2/orders/'.$orderid;
//     curl_setopt($curl, CURLOPT_URL, $url);
//     curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
//     curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
//     curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
//     curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
//     $state_result = curl_exec($curl);
//     $orderresult = json_decode($state_result,true); 
    
//     $modified = explode(" ",$orderresult['date_modified']);
//     $modified_date = date("Y-m-d h:i:s", strtotime($modified[3].'-'.$modified[2].'-'.$modified[1].' '.$modified[4]));
//     $created = explode(" ",$orderresult['date_created']);
//     $created_date = date("Y-m-d h:i:s", strtotime($created[3].'-'.$created[2].'-'.$created[1].' '.$created[4]));
    
//     $fname = $orderresult['billing_address']['first_name'];
//     $lname = $orderresult['billing_address']['last_name'];
//     $email = $orderresult['billing_address']['email'];
//     $add_orders = mysqli_query($con, "insert into orders (order_id,status_id,status,items_total,payment_status,refunded_amount,ip_address,geoip_country,currency_code,customer_message,first_name,last_name,company,street_1,street_2,city,state,zip,country,country_iso2,phone,email,order_source,modified_date,created_at) values ('".$orderresult['id']."','".$orderresult['status_id']."','".$orderresult['status']."','".$orderresult['items_total']."','".$orderresult['payment_status']."','".$orderresult['refunded_amount']."','".$orderresult['ip_address']."','".$orderresult['geoip_country']."','".$orderresult['currency_code']."','".$orderresult['customer_message']."','".$orderresult['billing_address']['first_name']."','".$orderresult['billing_address']['last_name']."','".$orderresult['billing_address']['company']."','".$orderresult['billing_address']['street_1']."','".$orderresult['billing_address']['street_2']."','".$orderresult['billing_address']['city']."','".$orderresult['billing_address']['state']."','".$orderresult['billing_address']['zip']."','".$orderresult['billing_address']['country']."','".$orderresult['billing_address']['country_iso2']."','".$orderresult['billing_address']['phone']."','".$orderresult['billing_address']['email']."','".$orderresult['order_source']."','$modified_date','$created_date')");    
//     if($add_orders)
//     {
//         $headers = array(
//             'X-Auth-Token: lvznqmz5lad75u9m76lqaoebbouwe80',
//             'Content-Type: application/json',
//             'Accept: application/json'
//         );

//         $post_body = array();
//         $post_body['auth_info'] = json_encode(array('login' => 'esimAPI', 'password' => '$0%6YrU$jJRh'));
//         $params = array('id' => $imsi);
//         $post_body['params'] = json_encode($params);
//         $URL = "https://mybilling.globalvoiceconnect.com:443/rest/Account/get_account_info";
//         $response = sendCurlPost($URL, $post_body);
//         http_response_code($response['info']['http_code']);
//         $iccidresult = json_decode($response['data'],true); 
//         $iproduct    = $iccidresult['account_info']['i_product'];
//         $iaccount    = $iccidresult['account_info']['i_account'];
//         if(isset($iaccount))
//         {
//             $pro_name = implode("_",explode(" ",$pro_name));
//             $post_body = array();
//             $post_body['auth_info'] = json_encode(array('login' => 'esimAPI', 'password' => '$0%6YrU$jJRh'));
//             $params = array('offset'=>0, 'name'=> $pro_name);
//             $post_body['params'] = json_encode($params);
//             $URL = "https://mybilling.telinta.com:443/rest/Product/get_product_list";
//             $response = sendCurlPost($URL, $post_body);
//             http_response_code($response['info']['http_code']);
//             $uresult = json_decode($response['data'],true); 
//             $iproduct1 = $uresult['product_list'][0]['i_product'];
//             if(isset($iproduct1))
//             {
//                 $start_date = date("Y-m-d H-i-s");
//                 $end_date   = date('Y-m-d H-i-s', strtotime("+29 day"));
//                 $post_body = array();
//                 $post_body['auth_info'] = json_encode(array('login' => 'esimAPI', 'password' => '$0%6YrU$jJRh'));
//                 $params = array(
//                     'account_info' => array("i_account" => $iaccount,
//                         "assigned_addons" => [
//                             array("i_product"=>$iproduct1, "addon_effective_from"=> $start_date, "addon_effective_to"=> $end_date)
//                         ]));
//                 $post_body['params'] = json_encode($params);
//                 $URL = "https://mybilling.telinta.com:443/rest/Account/update_account";
//                 $response = sendCurlPost($URL, $post_body);
//                 http_response_code($response['info']['http_code']);
//                 $result = json_decode($response['data'],true); 
//                 if(isset($result['i_account']))
//                 {
//                     $data = array('status_id'=>'10');
//                     $headers = array(
//                         'X-Auth-Token: lvznqmz5lad75u9m76lqaoebbouwe80',
//                         'Content-Type: application/json',
//                         'Accept: application/json'
//                     );
//                     $curl = curl_init();
//                     $url = 'https://api.bigcommerce.com/stores/7cb2a64bch/v2/orders/'.$orderid;
//                     curl_setopt($curl, CURLOPT_URL, $url);
//                     curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
//                     curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
//                     curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
//                     curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
//                     $state_result = curl_exec($curl);
//                     $result1 = json_decode($state_result,true); 
//                     if(!empty($result1['id']) && $result1['id']==$orderid)
//                     {
//                         $sku_val = "SKU_RE";
//                         $status = "Success";
//                         $val = "Success";
//                     }
//                     else
//                     {
//                         $sku_val = "SKU_RE";
//                         $status = "Pending";
//                         $val = "Status Update API Failed";
//                     }
//                 }
//                 else
//                 {
//                     $sku_val = "SKU_RE";
//                     $status = "Pending";
//                     $val = "Update Account API Failed";
//                 }
//             }
//             else
//             {
//                 $sku_val = "SKU_RE";
//                 $status = "Pending";
//                 $val = "Get Product List API Failed";
//             }
//         }
//         else
//         {
//             $sku_val = "SKU_RE";
//             $status = "Pending";
//             $val = "Get Account Info INFO API Failed";
//         }
//     }
//     else
//     {
//         $sku_val = "SKU_RE";
//         $status = "Pending";
//         $val = "Order API Failed";
//     }
// }

function sendCurlPost($url, $post_body)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_body);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    $res = curl_exec($ch);
    $info = curl_getinfo($ch);
    return array('data'=>$res, 'info'=>$info);
}
